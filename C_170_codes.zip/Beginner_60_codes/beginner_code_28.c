#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 28!\n");
    return 0;
}

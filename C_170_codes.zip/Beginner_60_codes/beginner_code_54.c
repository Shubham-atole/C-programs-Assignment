#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 54!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 43!\n");
    return 0;
}

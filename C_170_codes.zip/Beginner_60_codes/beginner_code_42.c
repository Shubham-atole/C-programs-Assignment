#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 42!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 55!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 14!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 5!\n");
    return 0;
}

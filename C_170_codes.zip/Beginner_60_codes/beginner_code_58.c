#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 58!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 8!\n");
    return 0;
}

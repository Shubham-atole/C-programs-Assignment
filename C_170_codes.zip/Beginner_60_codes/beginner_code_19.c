#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 19!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 39!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 7!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 52!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 17!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 22!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 31!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 2!\n");
    return 0;
}

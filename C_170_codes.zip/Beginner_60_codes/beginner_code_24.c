#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 24!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 26!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 23!\n");
    return 0;
}

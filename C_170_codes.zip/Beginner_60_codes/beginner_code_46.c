#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 46!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 3!\n");
    return 0;
}

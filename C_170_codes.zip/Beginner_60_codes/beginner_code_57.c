#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 57!\n");
    return 0;
}

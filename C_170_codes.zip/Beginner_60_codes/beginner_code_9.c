#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 9!\n");
    return 0;
}

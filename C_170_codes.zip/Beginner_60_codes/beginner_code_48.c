#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 48!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 25!\n");
    return 0;
}

#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 40!\n");
    return 0;
}

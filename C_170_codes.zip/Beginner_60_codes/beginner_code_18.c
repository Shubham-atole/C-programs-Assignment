#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 18!\n");
    return 0;
}

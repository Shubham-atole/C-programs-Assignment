#include <stdio.h>
int main() {
    printf("Hello, Beginner Program 38!\n");
    return 0;
}
